﻿namespace Test.Test1;

internal class IPhone
{
}
