﻿using AccessModifier.Models;
namespace Test;


internal class IPhone:Apple
{
    public IPhone()
    {
        Color = "Black";
        Console.WriteLine(Color);
    }
}

class IPhone
{

}
