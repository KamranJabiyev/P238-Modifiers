﻿namespace AccessModifier.Models;
class Apple
{
    private string model;
    //readonly property
    public int Storage { get; } = 1000;
    protected string Color { get; set; }
    public Apple()
    {
        Storage = 2000;
        Color = "black";
    }
    public string Model 
    {
        get 
        {
            if (model is not null)
            {
                return model;
            }
            return "Model is null";
        }
        set
        {
            if (value.Length >= 3)
            {
                model = value;
                return;
            }
            Console.WriteLine("Length should be minimum 3 simbol");
        }
    }

    #region Encapsulation
    //public void SetModel(string Model)
    //{
    //    if (Model.Length >= 3)
    //    {
    //        this.Model = Model;
    //        return;
    //    }
    //    Console.WriteLine("Length should be minimum 3 simbol");
    //}

    //public string GetModel()
    //{
    //    if (Model is not null)
    //    {
    //        return Model;
    //    }
    //    return "Model is null";
    //}
    #endregion

}
