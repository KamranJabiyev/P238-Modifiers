﻿using Test.Test1;

namespace AccessModifier.Models;

internal class Store
{
    public Store()
    {
        IPhone phone1 = new();
    }
}
