﻿using AccessModifier.Models;

Console.WriteLine("Hello, World!");

#region Access Modifiers
#region Public -class, all class members
//Apple apple = new();
//apple.Model = "IPhone15";
//Console.WriteLine(apple.Model);
#endregion
#region Private - all class members
//Apple apple = new();
//apple.SetModel("Ma");
//Console.WriteLine(apple.GetModel());
//apple.Model = "IPhone15";
//Console.WriteLine(apple.Model);
//apple.Storage = 1024;
//apple.Color = "Red";
//Console.WriteLine(apple.Color);
//Console.WriteLine(apple.Storage);
#endregion
#region Protected - all class members
//Apple apple = new Apple();
//apple.Color = "";
#endregion
#endregion
